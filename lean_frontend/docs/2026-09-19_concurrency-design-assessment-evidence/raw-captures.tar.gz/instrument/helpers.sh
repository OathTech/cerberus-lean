tokens_of() {
    local f="$1" toks
    toks=$(sed -n \
        -e 's/^Defined {value: "\([^"]*\)".*$/\1/p' \
        -e 's/^Undefined {ub: "\([^"]*\)".*$/\1/p' \
        -e 's/^Error {msg: .*$/ERROR/p' \
        -e 's/^internal error: \(.*\)$/INTERNAL_ERROR(\1)/p' \
        -e 's/^PANIC at .*failwithIImpl [^:]*:[0-9]*:[0-9]*: \(.*\)$/INTERNAL_ERROR(\1)/p' "$f" \
        | sed '/^INTERNAL_ERROR(/ s/ /_/g' | LC_ALL=C sort -u)   # tokens are whitespace-free (row format)
    sed -n 's/^Error {msg: "\(.*\)"}.*$/\1/p' "$f" > "$f.errmsgs"
    [[ -n "$toks" ]] || return 1
    printf '{%s}\n' "$(printf '%s\n' "$toks" | paste -sd, -)"
}

run_oracle() {   # <file.c> <out> [model-flag...]
    local src="$1" out="$2"; shift 2
    "$TIME_BIN" -v -o "$out.time" timeout "${TIMEOUT_SECS}s" "$CERBERUS_BIN" \
        --runtime="$PROJECT_ROOT/_build/install/default" \
        --nolibc --exec --batch --mode=exhaustive "$@" "$src" > "$out" 2>&1
}
run_lean() {     # <file.c> <json> <out> [model-flag...]
    local src="$1" json="$2" out="$3"; shift 3
    timeout "${TIMEOUT_SECS}s" "$CERBERUS_BIN" --runtime="$PROJECT_ROOT/_build/install/default" \
        --cabs-json "$src" > "$json" 2> "$json.err" || return 1
    [[ -s "$json" ]] || return 1
    "${CAPPED_TEST[@]}" "$TIME_BIN" -v -o "$out.time" timeout "${TIMEOUT_SECS}s" \
        env LEAN_ABORT_ON_PANIC=1 "$CERBERUS_LEAN_BIN" --batch "$json" "$@" 2>&1 \
        | grep -v '^cerberus-lean-proj env:' > "$out"
    return "${PIPESTATUS[0]}"
}

# read_rows <file> -> fills ROW_CLASS[name] ROW_TARGET[name]
declare -A ROW_CLASS ROW_TARGET
read_rows() {
    ROW_CLASS=(); ROW_TARGET=()
    local name cls target rest
    while read -r name cls target rest; do
        [[ -z "$name" || "$name" == \#* ]] && continue
        [[ -z "$cls" || -z "$target" || -n "$rest" ]] && { echo "Error: malformed row in $1: '$name $cls $target $rest'" >&2; exit 1; }
        ROW_CLASS["$name"]="$cls"; ROW_TARGET["$name"]="$target"
    done < "$1"
}

# run_all -> fills SET[name], ERRMSG_O[name], ERRMSG_L[name]; DIFF_FAIL count
declare -A SET ERRMSG_O ERRMSG_L
DIFF_FAIL=0
run_all() {
    local src name oset lset
    for src in "$LITMUS_DIR"/*.c; do
        name=$(basename "$src")
        run_oracle "$src" "$OUTPUT_DIR/$name.oracle" $MODEL_FLAG
        oset=$(tokens_of "$OUTPUT_DIR/$name.oracle") || {
            echo "[FAIL] $name: oracle output unparsable: $(head -1 "$OUTPUT_DIR/$name.oracle")"; DIFF_FAIL=$((DIFF_FAIL+1)); continue; }
        if ! run_lean "$src" "$OUTPUT_DIR/$name.json" "$OUTPUT_DIR/$name.lean" $MODEL_FLAG; then
            lrc=$?
            if is_cap_kill "$lrc" "$OUTPUT_DIR/$name.lean"; then
                echo "[FAIL] $name: Lean $(kill_label "$lrc" "$OUTPUT_DIR/$name.lean")"; DIFF_FAIL=$((DIFF_FAIL+1)); continue
            fi
            # nonzero rc is the runM convention for Undefined/Error lines: parse anyway
        fi
        lset=$(tokens_of "$OUTPUT_DIR/$name.lean") || {
            echo "[FAIL] $name: Lean output unparsable: $(head -1 "$OUTPUT_DIR/$name.lean" 2>/dev/null)"; DIFF_FAIL=$((DIFF_FAIL+1)); continue; }
        ERRMSG_O["$name"]=$(head -1 "$OUTPUT_DIR/$name.oracle.errmsgs" 2>/dev/null)
        ERRMSG_L["$name"]=$(head -1 "$OUTPUT_DIR/$name.lean.errmsgs" 2>/dev/null)
        if [[ "$oset" != "$lset" ]]; then
            echo "[DIFF] $name: oracle $oset vs Lean $lset"; DIFF_FAIL=$((DIFF_FAIL+1)); continue
        fi
        SET["$name"]="$oset"
    done
}

# seq_leg: the sequential model's spawn refusal, pinned on ONE corpus file
# run WITHOUT the model flag on both engines (S1: charter section 4.5 —
# a parallel program under CM_sequential is a typed refusal, never the
# pre-S1 silent serialization). Fails loudly if either engine runs it.
SEQ_LEG_FILE="${SEQ_LEG_FILE:-SB+sc_sc+sc_sc.c}"
SEQ_FAIL=0
seq_leg() {
    local src="$LITMUS_DIR/$SEQ_LEG_FILE" oset lset
    [[ -f "$src" ]] || { echo "[FAIL] SEQ leg: $SEQ_LEG_FILE missing"; SEQ_FAIL=1; return; }
    run_oracle "$src" "$OUTPUT_DIR/seq.oracle"
    oset=$(tokens_of "$OUTPUT_DIR/seq.oracle") || oset="<unparsable>"
    run_lean "$src" "$OUTPUT_DIR/seq.json" "$OUTPUT_DIR/seq.lean" || true
    lset=$(tokens_of "$OUTPUT_DIR/seq.lean") || lset="<unparsable>"
    local omsg lmsg
    omsg=$(head -1 "$OUTPUT_DIR/seq.oracle.errmsgs" 2>/dev/null); lmsg=$(head -1 "$OUTPUT_DIR/seq.lean.errmsgs" 2>/dev/null)
    if [[ "$oset" == "{ERROR}" && "$lset" == "{ERROR}" && "$omsg" == "$lmsg" && "$omsg" =~ ^model\ refused:\ thread\ spawn ]]; then
        echo "[MATCH] SEQ leg ($SEQ_LEG_FILE, no model flag): both engines refuse (\"$omsg\")"
    else
        echo "[FAIL] SEQ leg ($SEQ_LEG_FILE, no model flag): oracle $oset (\"$omsg\") vs Lean $lset (\"$lmsg\") — wanted the identical spawn refusal on both"
        SEQ_FAIL=1
    fi
}

# compare_to <rows-file> <label> -> prints per-row verdicts; returns fail count via COMPARE_FAIL
COMPARE_FAIL=0; declare -A CLASS_RED
compare_to() {
    read_rows "$1"
    local name target cls n_files=0
    COMPARE_FAIL=0; CLASS_RED=()
    for src in "$LITMUS_DIR"/*.c; do
        name=$(basename "$src"); n_files=$((n_files+1))
        if [[ -z "${ROW_CLASS[$name]:-}" ]]; then
            echo "[FAIL] $name: no row in $(basename "$1") (bijection)"; COMPARE_FAIL=$((COMPARE_FAIL+1)); continue
        fi
        [[ -n "${SET[$name]:-}" ]] || { COMPARE_FAIL=$((COMPARE_FAIL+1)); continue; }   # already reported by run_all
        target="${ROW_TARGET[$name]}"; cls="${ROW_CLASS[$name]}"
        if [[ "$target" == "REFUSE" ]]; then
            if [[ "${SET[$name]}" == "{ERROR}" && "${ERRMSG_O[$name]}" =~ $REFUSE_RE && "${ERRMSG_L[$name]}" =~ $REFUSE_RE ]]; then
                echo "[MATCH] $name ($cls): REFUSE (\"${ERRMSG_O[$name]}\")"
            else
                echo "[MISMATCH] $name ($cls): $2 REFUSE vs engines ${SET[$name]}${ERRMSG_O[$name]:+ (\"${ERRMSG_O[$name]}\")}"
                COMPARE_FAIL=$((COMPARE_FAIL+1)); CLASS_RED["$cls"]=1
            fi
        elif [[ "${SET[$name]}" == "$target" ]]; then
            echo "[MATCH] $name ($cls): ${SET[$name]}"
        else
            echo "[MISMATCH] $name ($cls): $2 $target vs engines ${SET[$name]}${ERRMSG_O[$name]:+ (\"${ERRMSG_O[$name]}\")}"
            COMPARE_FAIL=$((COMPARE_FAIL+1)); CLASS_RED["$cls"]=1
        fi
    done
    for name in "${!ROW_CLASS[@]}"; do
        [[ -f "$LITMUS_DIR/$name" ]] || { echo "[FAIL] row $name in $(basename "$1") has no file (bijection)"; COMPARE_FAIL=$((COMPARE_FAIL+1)); }
    done
    if [[ $n_files -eq 0 ]]; then echo "[FAIL] zero programs under $LITMUS_DIR (vacuous pass refused)"; COMPARE_FAIL=$((COMPARE_FAIL+1)); fi
}
