from pathlib import Path
import json,subprocess,hashlib
root=Path('.tmp/item7-audit'); cases=root/'core'; cases.mkdir(exist_ok=True)
texts={
 'let-long': 'let (a: integer, b: integer) = (1,2,3) in pure (Specified(a+b))',
 'let-short': 'let (a: integer, b: integer, c: integer) = (1,2) in pure (Specified(a+b))',
 'let-fit': 'let (a: integer, b: integer) = (1,2) in pure (Specified(a+b))',
 'let-nested': 'let ((a: integer, b: integer), c: integer) = ((1,2,3),4) in pure (Specified(a+b+c))',
 'pure-let': 'pure (Specified(let (a: integer, b: integer) = (1,2,3) in a+b))',
 'pure-let-error': 'pure (Specified(let (a: integer, b: integer) = (1,2,error(<<<surplus>>>,3)) in a+b))',
 'let-error': 'let (a: integer, b: integer) = (1,2,error(<<<surplus>>>,3)) in pure (Specified(a+b))',
 'case-fallback': 'case (1,2,3) of | (a: integer, b: integer) => pure (Specified(a+b)) | _ => pure (Specified(9)) end',
}
for strength in ['weak','strong']:
 for name,pat,vals in [('long','(a: integer,b: integer)','pure(1),pure(2),pure(3)'),('short','(a: integer,b: integer,c: integer)','pure(1),pure(2)'),('fit','(a: integer,b: integer)','pure(1),pure(2)'),('error','(a: integer,b: integer)','pure(1),pure(2),pure(error(<<<surplus>>>,3))')]:
  texts[f'{strength}-{name}']=f'let {strength} {pat} = unseq({vals}) in pure (Specified(a+b))'
texts['par-long']='let weak (a: integer,b: integer) = par(pure(1),pure(2),pure(3)) in pure(Specified(a+b))'
texts['par-fit']='let weak (a: integer,b: integer) = par(pure(1),pure(2)) in pure(Specified(a+b))'
for k,v in texts.items():
 (cases/(k+'.core')).write_text('proc main (): eff loaded integer :=\n  '+v+'\n')
for kind in ['fun','proc']:
 decl='fun f(a: integer,b: integer): integer := a+b\n' if kind=='fun' else 'proc f(a: integer,b: integer): eff loaded integer := pure(Specified(a+b))\n'
 for name,args in [('long','1,2,3'),('short','1'),('fit','1,2'),('error','1,2,error(<<<surplus>>>,3)')]:
  expr=f'pure(Specified(f({args})))' if kind=='fun' else f'pcall(f,{args})'
  (cases/(kind+'-'+name+'.core')).write_text(decl+'proc main (): eff loaded integer :=\n  '+expr+'\n')
for name,args in [('long','2,3'),('short',''),('fit','2'),('error','2,error(<<<surplus>>>,3)')]:
 (cases/('run-'+name+'.core')).write_text('proc main (): eff loaded integer :=\n  save loop: loaded integer (i: integer := 1) in\n    if i == 1 then run loop('+args+') else pure(Specified(i))\n')
if __name__=='__main__':
 roots={'fork':Path.cwd(), 'pristine':Path('.validation-foundations/independent-oracle-v2/cerberus').resolve()}
 results=[]
 for engine,base in roots.items():
  for p in sorted(cases.glob('*.core')):
   for mode,flags in [('default',[]),('rewrite',['--rewrite']),('typed',['--typecheck-core']),('typed-rewrite',['--typecheck-core','--rewrite']),('typed-dump',['--typecheck-core','--pp=core'])]:
    cmd=[str(base/'_build/default/backend/driver/main.exe'),'--runtime='+str(base/'_build/install/default'),'--nolibc']
    cmd+=['--exec','--batch','--mode=exhaustive'] if mode!='typed-dump' else []
    cmd+=flags+[str(p)]
    out=root/'core-captures'/engine/p.stem; out.mkdir(parents=True,exist_ok=True)
    try:
     r=subprocess.run(cmd,capture_output=True,timeout=3 if p.stem=='run-short' else 20,env={**__import__('os').environ,'NO_COLOR':'1','TERM':'dumb'})
    except subprocess.TimeoutExpired as e:
     r=subprocess.CompletedProcess(cmd,124,e.stdout or b'',e.stderr or b'')
    (out/(mode+'.stdout')).write_bytes(r.stdout); (out/(mode+'.stderr')).write_bytes(r.stderr)
    row={'engine':engine,'case':p.stem,'mode':mode,'command':cmd,'exit':r.returncode,'stdout':str(out/(mode+'.stdout')),'stderr':str(out/(mode+'.stderr')),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()}
    results.append(row)
    (root/'core-results.json').write_text(json.dumps(results,indent=2)+'\n')
  print(engine,'complete',flush=True)
 (root/'core-results.json').write_text(json.dumps(results,indent=2)+'\n')
 print('Recorded',len(results),'executions (collector only; inspect individual results).')
