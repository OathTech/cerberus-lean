from pathlib import Path
import json,hashlib,re,collections
root=Path('.tmp/item7-audit')
initial=json.loads((root/'core-results.json').read_text())
corrected=json.loads((root/'core-results-run-fixed.json').read_text())
adjacent=json.loads((root/'adjacent-results.json').read_text())
invalid=[r for r in initial if r['case'].startswith('run-')]
valid=[r for r in initial if r not in invalid]+corrected+adjacent
assert len(initial)==300 and len(invalid)==40 and len(corrected)==40 and len(adjacent)==80
assert len(valid)==380
for row in initial+corrected+adjacent:
 for stream in ['stdout','stderr']:
  assert hashlib.sha256(Path(row[stream]).read_bytes()).hexdigest()==row[stream+'_sha256']

def observation(r):
 out=Path(r['stdout']).read_text().strip();err=Path(r['stderr']).read_text().strip()
 if r['exit']==124: return 'timeout (bounded probe)'
 if r['mode']=='typed-dump' and r['exit']==0: return 'typing accepted; typed dump retained'
 if out.startswith(('Defined {','Error {','Undefined {')): return out.splitlines()[0]
 if 'error:' in err:
  return next((s.strip() for s in err.splitlines() if 'error:' in s),'error')
 return (out or err).splitlines()[0] if (out or err) else 'empty'
index={(r['engine'],r['case'],r['mode']):r for r in valid}
for engine in ['fork','pristine']:
 for case,val in [('fun-error',3),('proc-error',3),('memop-error',1)]:
  for mode in ['default','rewrite']:
   r=index[engine,case,mode]; assert r['exit']==1 and Path(r['stdout']).read_text().strip()=='Error {msg: "surplus"}'
  for mode in ['typed','typed-rewrite']:
   r=index[engine,case,mode]; assert r['exit']==0 and f'Specified({val})' in Path(r['stdout']).read_text()
  assert 'surplus' not in Path(index[engine,case,'typed-dump']['stdout']).read_text()
 for case,val in [('run-fixed-error',2),('run-short-stale',11),('run-short-control',21)]:
  for mode in ['default','rewrite','typed','typed-rewrite']:
   r=index[engine,case,mode]; assert r['exit']==0 and f'Specified({val})' in Path(r['stdout']).read_text()
 for case in ['ccall-short','ccall-error','memop-short']:
  assert index[engine,case,'typed-dump']['exit']==0
 assert 'surplus' not in Path(index[engine,'ccall-error','typed-dump']['stdout']).read_text()
for case in ['let-long','let-short','let-nested','pure-let','weak-long','weak-short','strong-long','strong-short','par-long']:
 for mode in ['default','rewrite']:
  r=index['fork',case,mode]; assert r['exit']==1 and 'ill-formed program' in Path(r['stdout']).read_text(),r
 for mode in ['typed','typed-rewrite','typed-dump']:
  r=index['fork',case,mode]; assert r['exit']==1 and 'different arity' in Path(r['stderr']).read_text(),r
for case in ['let-fit','weak-fit','strong-fit','par-fit','fun-fit','proc-fit']:
 for mode in ['default','rewrite','typed','typed-rewrite']:
  r=index['fork',case,mode]; assert r['exit']==0 and 'Specified(3)' in Path(r['stdout']).read_text(),r
native=(root/'native-run.log').read_text().splitlines()
assert sum(s.startswith('PASS:') for s in native)==459
summary={'provenance':'[AGENT] derived from raw capture files; not a differential gate',
 'valid_inputs':len({r['case'] for r in valid}),'valid_executions':len(valid),
 'instrument_parse_errors_retained':len(invalid),'native_assertions_passed':459,
 'engines':['fork b85f5bc83','pristine b9aeedcb4'],
 'exit_counts_valid':dict(collections.Counter(str(r['exit']) for r in valid)),
 'rows':[dict(engine=r['engine'],case=r['case'],mode=r['mode'],exit=r['exit'],observation=observation(r)) for r in valid]}
(root/'focused-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
lines=['# Focused Core observations','', '[AGENT] Derived from 380 valid invocations on 38 inputs; 40 earlier reviewer syntax-error invocations excluded. Collector success alone is not a pass verdict. Raw sources, commands, streams and hashes are retained.','', '| Engine | Case | Mode | Exit | Observation |','|---|---|---|---|---|']
for r in summary['rows']:
 lines.append('| '+' | '.join(str(r[k]).replace('|','\\|') for k in ['engine','case','mode','exit','observation'])+' |')
(root/'focused-summary.md').write_text('\n'.join(lines)+'\n')
print({k:v for k,v in summary.items() if k!='rows'})
