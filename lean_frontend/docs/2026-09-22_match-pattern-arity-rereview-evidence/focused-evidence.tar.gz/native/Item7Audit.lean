import Core_aux
import Core_typing
import Core_run
import Core_reduction
import Core_eval
import Core_rewrite
import Core_aux_lemMeasureProofs

namespace Item7Audit

def key (n : Nat) : sym := Symbol "audit" n SD_None
def leaf (n : Nat) : pattern := Pattern [] (CaseBase (some (key n), BTy_unit))
def tup (ps : List pattern) : pattern := Pattern [] (CaseCtor Ctuple ps)
def flat (n : Nat) : pattern := tup ((List.range n).map leaf)
def vals (n : Nat) : value := Vtuple (List.replicate n Vunit)
def peU : pexpr := mk_value_pe Vunit
def body : expr Unit := Expr [] (Epure peU)
def ty (n : Nat) : core_base_type := BTy_tuple (List.replicate n BTy_unit)
def peTuple (n : Nat) : pexpr := Pexpr [] () (PEctor Ctuple (List.replicate n peU))
def listPat : pattern := Pattern [] (CaseCtor Ccons [flat 2, Pattern [] (CaseCtor (Cnil (ty 2)) [])])
def listBad : value := Vlist (ty 3) [vals 3]

theorem list_match_declines : match_pattern listPat listBad = none := rfl
theorem list_subst_declines : subst_pattern listPat (mk_value_pe listBad) body = none := rfl
theorem nested_declines : subst_pattern (tup [leaf 9, flat 2])
    (mk_value_pe (Vtuple [Vunit, vals 3])) body = none := rfl
theorem selector_falls_through : select_case subst_sym_expr listBad
    [(listPat, Expr [] (Epure (mk_value_pe Vtrue))), (leaf 99, body)] = some body := rfl
#print axioms list_match_declines
#print axioms list_subst_declines
#print axioms nested_declines
#print axioms selector_falls_through

def accepted {α β : Type} : exceptM α β → Bool
  | Result _ => true | Exception _ => false

def tP (t : core_base_type) (p : pexpr) := typecheck_pexpr (fmapEmpty : Fmap sym (CerbLocation.Loc × tag_definition)) empty_env t p
def tE (t : core_base_type) (e : expr Unit) := typecheck_expr Normal_callconv (fmapEmpty : Fmap sym (CerbLocation.Loc × tag_definition)) empty_env t e

def check (s : String) (b : Bool) : IO Unit := do
  unless b do throw (IO.userError s!"FAIL: {s}")
  IO.println s!"PASS: {s}"

def unitArena : expr core_run_annotation := Expr [] (Epure peU)
def route (p : pattern) (v : value) (which : Nat) : Bool :=
  let e : expr core_run_annotation := Expr [] (Epure (mk_value_pe v))
  let ann : expr core_run_annotation := Expr [] (Eannot [] e)
  let arena : expr core_run_annotation := match which with
    | 0 => Expr [] (Elet p (mk_value_pe v) unitArena)
    | 1 => Expr [] (Elet p (Pexpr [] () (PEctor Ctuple [])) unitArena)
    | 2 => Expr [] (Ewseq p e unitArena)
    | 3 => Expr [] (Ewseq p ann unitArena)
    | 4 => Expr [] (Esseq p e unitArena)
    | _ => Expr [] (Esseq p ann unitArena)
  let stubEval : pexpr → stExceptUndefM pexpr core_run_state core_run_cause :=
    fun _ _ => Exception (Illformed_program "unexpected partial evaluator")
  let stubFull : pexpr → core_run_state → exceptM (t0 value × core_run_state) core_run_cause :=
    fun _ st => Result (Defined v, st)
  match one_step0 stubEval stubFull [fmapEmpty] arena with
  | some (TAU _ _ _) => true
  | some (TAU_WITH_RUNSTATE _ m) =>
      match m (default : core_run_state) with
      | Exception (Illformed_program _) => false
      | Result (Defined _, _) => true
      | _ => false
  | _ => false

def run : IO Unit := do
  for n in List.range 7 do
    for m in List.range 7 do
      let eq := n == m
      check s!"matcher {n}/{m}" ((match_pattern (flat n) (vals m)).isSome == eq)
      check s!"pattern typing {n}/{m}" (accepted (typecheck_pattern (ty n) (flat m)) == eq)
      check s!"tuple expression typing {n}/{m}" (accepted (tP (ty n) (peTuple m)) == eq)
      check s!"tuple value typing {n}/{m}" (accepted (tP (ty n) (mk_value_pe (vals m))) == eq)
      check s!"unseq typing {n}/{m}" (accepted (tE (ty n) (Expr [] (Eunseq (List.replicate m body)))) == (eq && m >= 2))
      check s!"par typing {n}/{m}" (accepted (tE (ty n) (Expr [] (Epar (List.replicate m body)))) == (eq && m >= 2))
      check s!"value substitution {n}/{m}" ((subst_pattern (flat n) (mk_value_pe (vals m)) body).isSome == eq)
      check s!"expression substitution {n}/{m}" ((subst_pattern (flat n) (peTuple m) body).isSome == eq)
      check s!"nested substitution {n}/{m}" ((subst_pattern (tup [leaf 9, flat n]) (mk_value_pe (Vtuple [Vunit, vals m])) body).isSome == eq)
  for which in List.range 6 do
    check s!"reduction route {which} rejects 2/3" (!(route (flat 2) (vals 3) which))
    check s!"reduction route {which} rejects 3/2" (!(route (flat 3) (vals 2) which))
    check s!"reduction route {which} accepts 2/2" (route (flat 2) (vals 2) which)
  let f := key 123
  let tags : Fmap sym (CerbLocation.Loc × tag_definition) := fmapEmpty
  let funEnv : typing_env := singleton_tdecl_env (Sym f) (TDfun BTy_unit [BTy_unit])
  let procEnv : typing_env := singleton_tdecl_env (Sym f) (TDproc BTy_unit [BTy_unit])
  let runEnv : typing_env := { empty_env with labs := fmapAddBy Lem_Basic_classes.ordCompare f (BTy_unit, [BTy_unit]) empty_env.labs }
  for m in List.range 4 do
    let args := List.replicate m peU
    let inf := infer_pexpr tags funEnv (Pexpr [] () (PEcall (Sym f) args))
    let chk := typecheck_pexpr tags funEnv BTy_unit (Pexpr [] () (PEcall (Sym f) args))
    let pc := typecheck_expr Normal_callconv tags procEnv BTy_unit (Expr [] (Eproc () (Sym f) args))
    let run := typecheck_expr Normal_callconv tags runEnv BTy_unit (Expr [] (Erun () f args))
    let pcnt := fun r => match r with | Result (Pexpr _ _ (PEcall _ ps)) => some ps.length | _ => none
    let ecnt := fun r => match r with | Result (Expr _ (Eproc _ _ ps)) => some ps.length | Result (Expr _ (Erun _ _ ps)) => some ps.length | _ => none
    IO.println s!"DIAGNOSTIC: one formal/{m} actuals: infer-call={repr (pcnt inf)}, check-call={repr (pcnt chk)}, proc={repr (ecnt pc)}, run={repr (ecnt run)}"
  IO.println "Item7Audit: focused assertions completed; diagnostic call counts require review."
end Item7Audit

def main : IO UInt32 := do
  Item7Audit.run
  return 0
