from pathlib import Path
import json,subprocess,hashlib,collections
root=Path('.tmp/item7-audit'); base='df85e95b7b37826dfb3f2ac97a41473580f1e0b9'
def git(*xs): return subprocess.check_output(['git',*xs],text=True)
def rows(text):return [s for s in text.splitlines() if s and not s.startswith('#')][1:]
a=rows(git('show',base+':scripts/failure_reach_register.txt'));b=rows(Path('scripts/failure_reach_register.txt').read_text())
added=list((collections.Counter(b)-collections.Counter(a)).elements());removed=list((collections.Counter(a)-collections.Counter(b)).elements())
assert len(a)==238 and len(b)==239 and len(added)==1 and not removed
assert '\ttuple_arity_error\t' in added[0]
changed=git('diff','--name-only',base+'..HEAD').splitlines()
assert len(changed)==21
unit=Path('scripts/test_unit.sh').read_text();lake=Path('lean_frontend/lakefile.toml').read_text()
for s in ['enum-data-test','match-pattern-arity-test']: assert s in unit and s in lake
out={'provenance':'[AGENT] derived source/rebase checks','base':base,'head':git('rev-parse','HEAD').strip(),'status':git('status','--porcelain').strip(),'commits':git('log','--format=%H %s',base+'..HEAD').splitlines(),'changed_files':changed,'register_before':len(a),'register_after':len(b),'register_added':added,'register_removed':removed,'both_units_registered':True}
(root/'rebase-review.json').write_text(json.dumps(out,indent=2)+'\n')
print({k:v for k,v in out.items() if k not in ['commits','changed_files','register_added']})
