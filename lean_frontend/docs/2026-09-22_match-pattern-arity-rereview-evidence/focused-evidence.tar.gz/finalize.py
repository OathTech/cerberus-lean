"""Fill the audit from completed, unchanged-source receipts; run after retention."""
from pathlib import Path
from datetime import datetime,timezone
import json
src=Path('.tmp/item7-audit')
r=json.loads((src/'full/report.json').read_text()); t=json.loads((src/'three-engine/report.json').read_text())
assert r['status']=='passed' and r['source_unchanged'] and r['selection_complete']
assert r['source_before']==r['source_after'] and r['source_before']['status']==''
assert r['source_before']['head']=='b85f5bc83ed79554af3bd3bb4f4a16582917ccb5'
assert r['external_inputs_before']==r['external_inputs_after']
assert r['artifacts_before']==r['artifacts_after']
assert len(r['lanes'])==39 and all(x['status']=='passed' and x['exit_status']==0 for x in r['lanes'])
assert t['status']=='passed' and t['source_unchanged'] and t['source']['status']==''
assert t['source']['head']==r['source_before']['head']
expected={'semantic_agreement':835,'matching_failure':28,'reviewed_difference':7,'interface_agreement':2}
assert t['counts']==expected
assert t['lean_counts']=={'lean_agreement':830,'lean_both_undecodable':12,'lean_difference':28,'lean_not_applicable':2}
c=json.loads((src/'three-engine-comparison.json').read_text()); assert c['same_ids_and_classes']
start=datetime.strptime(r['started_utc'],'%Y%m%dT%H%M%S.%fZ').replace(tzinfo=timezone.utc)
end=datetime.fromisoformat(r['finished_utc'])
minutes=(end-start).total_seconds()/60
s=(src/'audit-draft.md').read_text()
s=s.replace('Independent verification: **PENDING FULL AND THREE-ENGINE RESULTS**. Focused evidence already comprises', 'Independent verification: **39/39 full-battery commands passed on clean, unchanged `b85f5bc83`**; the separate three-engine report was also completed and reviewed. Focused evidence comprises')
full=f'''The full run completed from {start.strftime('%H:%M:%S')} to {end.strftime('%H:%M:%S')} UTC (derived wall time: **{minutes:.1f} minutes**). Its summary, verbatim:

```text
{(src/'full/summary.txt').read_text().rstrip()}
```

Source identity is equal before/after, with clean status and the reviewed head. External-input inventories and all **{len(r['artifacts_before']):,} recorded artifact entries** are also equal before/after. Derived highlights from the retained receipts:

| Check | Independent result |
|---|---|
| Unit executables | 14 passed, zero failed; both enum and arity executables present |
| Fuel forms | 81 workers: 62 measured, 13 absorbing, zero reachable ambient, six ambient outside the drive cone |
| Failure reach | 239 rows: 170 unreachable by reviewed invariant, 48 reachable, 21 unknown; zero discardable |
| Fork drift | 82 surface files, 29 pinned generated deltas; Lem pin `38f87d5` matches |
| GCC oracle | 2,014 programs: 1,917 agreements, 12 triaged, 85 skipped; zero regressions and zero improvements against its baseline |
| Observation harness | 93/93 plants passed |
| Pristine corpus | 835 semantic agreements, 28 matching failures, seven reviewed differences, two interface agreements |
| Pristine plant lane | 51 plant-ok, one plant-rejected, one semantic agreement |
| Pristine libxml2 chvalid | Four semantic agreements |

All 39 lane processes exited 0; this does not mean that every individual corpus input is a successful C execution. The recorded classifications above preserve that distinction.'''
s=s.replace('**FULL_RESULT_PLACEHOLDER**',full)
three='''The separate C5 three-engine report covers 872 rows. The fork/pristine counts remain 835/28/7/2. Its **non-gating Lean column** has 830 agreements, 28 differences, 12 both-undecodable rows and two not-applicable rows. The same 40 nonmatching IDs have the same classes as the previously committed independent run-digest audit (`97c98bcce`, reviewed head `24f19d6f5`); the reference identity and comparison are retained. This is a historical cross-feature comparison, not a new A/B run on the exact item-7 base, and is not a claim that all three engines agree. C5 records clean `b85f5bc83` and unchanged source.'''
s=s.replace('**THREE_ENGINE_PLACEHOLDER**',three)
assert 'PLACEHOLDER' not in s and 'PENDING FULL' not in s
out=Path('lean_frontend/docs/2026-09-22_match-pattern-arity-rereview.md');out.write_text(s)
print(out,'full minutes',round(minutes,2),'artifact entries',len(r['artifacts_before']))
