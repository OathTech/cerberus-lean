from pathlib import Path
import subprocess,json,os,hashlib
root=Path('.tmp/item7-audit'); cases=root/'adjacent-core'; cases.mkdir(exist_ok=True)
texts={
'run-short-stale':'save loop: loaded integer (i: integer := 0, j: integer := 10) in if i < 1 then run loop(1) else pure(Specified(i+j))',
'run-short-control':'save loop: loaded integer (i: integer := 0, j: integer := 10) in if i < 1 then run loop(1,20) else pure(Specified(i+j))',
'memop-short':'let strong b: boolean = memop(PtrEq,NULL(void)) in pure(Specified(if b then 1 else 0))',
'memop-fit':'let strong b: boolean = memop(PtrEq,NULL(void),NULL(void)) in pure(Specified(if b then 1 else 0))',
'memop-error':'let strong b: boolean = memop(PtrEq,NULL(void),NULL(void),error(<<<surplus>>>,3)) in pure(Specified(if b then 1 else 0))',
'ccall-short':"ccall('signed int(signed int)*',Specified(NULL(void)))",
'ccall-fit':"ccall('signed int(signed int)*',Specified(NULL(void)),NULL(void))",
'ccall-error':"ccall('signed int(signed int)*',Specified(NULL(void)),NULL(void),error(<<<surplus>>>,3))",
}
for name,body in texts.items(): (cases/(name+'.core')).write_text('proc main (): eff loaded integer :=\n  '+body+'\n')
rows=[]
for engine,base in {'fork':Path.cwd(),'pristine':Path('.validation-foundations/independent-oracle-v2/cerberus').resolve()}.items():
 for p in sorted(cases.glob('*.core')):
  for mode,flags in [('default',[]),('rewrite',['--rewrite']),('typed',['--typecheck-core']),('typed-rewrite',['--typecheck-core','--rewrite']),('typed-dump',['--typecheck-core','--pp=core'])]:
   cmd=[str(base/'_build/default/backend/driver/main.exe'),'--runtime='+str(base/'_build/install/default'),'--nolibc']
   if mode!='typed-dump': cmd+=['--exec','--batch','--mode=exhaustive']
   cmd+=flags+[str(p)]
   try: r=subprocess.run(cmd,capture_output=True,timeout=10,env={**os.environ,'NO_COLOR':'1','TERM':'dumb'})
   except subprocess.TimeoutExpired as e: r=subprocess.CompletedProcess(cmd,124,e.stdout or b'',e.stderr or b'')
   out=root/'adjacent-captures'/engine/p.stem;out.mkdir(parents=True,exist_ok=True)
   for stream,data in [('stdout',r.stdout),('stderr',r.stderr)]: (out/(mode+'.'+stream)).write_bytes(data)
   row={'engine':engine,'case':p.stem,'mode':mode,'command':cmd,'exit':r.returncode}
   for stream,data in [('stdout',r.stdout),('stderr',r.stderr)]: row.update({stream:str(out/(mode+'.'+stream)),stream+'_sha256':hashlib.sha256(data).hexdigest()})
   rows.append(row)
(root/'adjacent-results.json').write_text(json.dumps(rows,indent=2)+'\n')
print('Recorded',len(rows),'executions; inspect outcomes individually.')
for r in rows:
 if r['engine']=='fork' and r['mode'] in ['default','typed','typed-dump']:
  print(r['case'],r['mode'],r['exit'],Path(r['stdout']).read_text()[-400:].strip(),Path(r['stderr']).read_text()[-200:].strip())
