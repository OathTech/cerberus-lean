import json,pathlib,subprocess,time,datetime
root=pathlib.Path('.tmp/item7-audit')
started=time.monotonic()
with (root/'queue.jsonl').open('w') as log:
 while True:
  p=pathlib.Path('/proc/2460461/cmdline')
  busy=p.exists() and b'release.py' in p.read_bytes()
  log.write(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'waiting_for_sc_battery':busy})+'\n'); log.flush()
  if not busy: break
  time.sleep(10)
print('Other battery finished; independent rebuild starting.',flush=True)
t=time.monotonic()
with (root/'rebuild.log').open('w') as log:
 r=subprocess.run(['/home/dev/projects/cerberus-lean-proj/scripts/ce','bash',str(root/'rebuild.sh')],stdout=log,stderr=subprocess.STDOUT)
(root/'rebuild.json').write_text(json.dumps({'exit_code':r.returncode,'build_seconds':time.monotonic()-t,'total_seconds':time.monotonic()-started},indent=2)+'\n')
print('Independent rebuild exit',r.returncode,flush=True)
raise SystemExit(r.returncode)
