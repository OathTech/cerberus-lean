# Focused Core observations

[AGENT] Derived from 380 valid invocations on 38 inputs; 40 earlier reviewer syntax-error invocations excluded. Collector success alone is not a pass verdict. Raw sources, commands, streams and hashes are retained.

| Engine | Case | Mode | Exit | Observation |
|---|---|---|---|---|
| fork | case-fallback | default | 1 | .tmp/item7-audit/core/case-fallback.core:2:75: error: unexpected token '=>' |
| fork | case-fallback | rewrite | 1 | .tmp/item7-audit/core/case-fallback.core:2:75: error: unexpected token '=>' |
| fork | case-fallback | typed | 1 | .tmp/item7-audit/core/case-fallback.core:2:75: error: unexpected token '=>' |
| fork | case-fallback | typed-rewrite | 1 | .tmp/item7-audit/core/case-fallback.core:2:75: error: unexpected token '=>' |
| fork | case-fallback | typed-dump | 1 | .tmp/item7-audit/core/case-fallback.core:2:75: error: unexpected token '=>' |
| fork | fun-error | default | 1 | Error {msg: "surplus"} |
| fork | fun-error | rewrite | 1 | Error {msg: "surplus"} |
| fork | fun-error | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | fun-error | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | fun-error | typed-dump | 0 | typing accepted; typed dump retained |
| fork | fun-fit | default | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | fun-fit | rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | fun-fit | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | fun-fit | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | fun-fit | typed-dump | 0 | typing accepted; typed dump retained |
| fork | fun-long | default | 125 | internal error: CALL() \|params\|= 2 <> \|args\|= 3 |
| fork | fun-long | rewrite | 125 | internal error: CALL() \|params\|= 2 <> \|args\|= 3 |
| fork | fun-long | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | fun-long | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | fun-long | typed-dump | 0 | typing accepted; typed dump retained |
| fork | fun-short | default | 125 | internal error: CALL() \|params\|= 2 <> \|args\|= 1 |
| fork | fun-short | rewrite | 125 | internal error: CALL() \|params\|= 2 <> \|args\|= 1 |
| fork | fun-short | typed | 125 | internal error: CALL() \|params\|= 2 <> \|args\|= 1 |
| fork | fun-short | typed-rewrite | 125 | internal error: CALL() \|params\|= 2 <> \|args\|= 1 |
| fork | fun-short | typed-dump | 0 | typing accepted; typed dump retained |
| fork | let-error | default | 1 | Error {msg: "surplus"} |
| fork | let-error | rewrite | 1 | Error {msg: "surplus"} |
| fork | let-error | typed | 1 | .tmp/item7-audit/core/let-error.core:2:34: error: this expression is of type 'tuple of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | let-error | typed-rewrite | 1 | .tmp/item7-audit/core/let-error.core:2:34: error: this expression is of type 'tuple of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | let-error | typed-dump | 1 | .tmp/item7-audit/core/let-error.core:2:34: error: this expression is of type 'tuple of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | let-fit | default | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | let-fit | rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | let-fit | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | let-fit | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | let-fit | typed-dump | 0 | typing accepted; typed dump retained |
| fork | let-long | default | 1 | Error {msg: "ill-formed program: `Elet: the pattern didn't match pe1'"} |
| fork | let-long | rewrite | 1 | Error {msg: "ill-formed program: `PElet: the pattern didn't match pe1'"} |
| fork | let-long | typed | 1 | .tmp/item7-audit/core/let-long.core:2:34: error: this expression is of type 'tuple of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | let-long | typed-rewrite | 1 | .tmp/item7-audit/core/let-long.core:2:34: error: this expression is of type 'tuple of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | let-long | typed-dump | 1 | .tmp/item7-audit/core/let-long.core:2:34: error: this expression is of type 'tuple of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | let-nested | default | 1 | Error {msg: "ill-formed program: `Elet: the pattern didn't match pe1'"} |
| fork | let-nested | rewrite | 1 | Error {msg: "ill-formed program: `PElet: the pattern didn't match pe1'"} |
| fork | let-nested | typed | 1 | .tmp/item7-audit/core/let-nested.core:2:49: error: this expression is of type 'tuple of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | let-nested | typed-rewrite | 1 | .tmp/item7-audit/core/let-nested.core:2:49: error: this expression is of type 'tuple of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | let-nested | typed-dump | 1 | .tmp/item7-audit/core/let-nested.core:2:49: error: this expression is of type 'tuple of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | let-short | default | 1 | Error {msg: "ill-formed program: `Elet: the pattern didn't match pe1'"} |
| fork | let-short | rewrite | 1 | Error {msg: "ill-formed program: `PElet: the pattern didn't match pe1'"} |
| fork | let-short | typed | 1 | .tmp/item7-audit/core/let-short.core:2:46: error: this expression is of type 'tuple of a different arity' but an expression of type '(integer,integer,integer)' was expected |
| fork | let-short | typed-rewrite | 1 | .tmp/item7-audit/core/let-short.core:2:46: error: this expression is of type 'tuple of a different arity' but an expression of type '(integer,integer,integer)' was expected |
| fork | let-short | typed-dump | 1 | .tmp/item7-audit/core/let-short.core:2:46: error: this expression is of type 'tuple of a different arity' but an expression of type '(integer,integer,integer)' was expected |
| fork | par-fit | default | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | par-fit | rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | par-fit | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | par-fit | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | par-fit | typed-dump | 0 | typing accepted; typed dump retained |
| fork | par-long | default | 1 | Error {msg: "ill-formed program: `Ewseq: the pattern didn't match e1'"} |
| fork | par-long | rewrite | 1 | Error {msg: "ill-formed program: `Ewseq: the pattern didn't match e1'"} |
| fork | par-long | typed | 1 | .tmp/item7-audit/core/par-long.core:2:38: error: this expression is of type 'par of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | par-long | typed-rewrite | 1 | .tmp/item7-audit/core/par-long.core:2:38: error: this expression is of type 'par of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | par-long | typed-dump | 1 | .tmp/item7-audit/core/par-long.core:2:38: error: this expression is of type 'par of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | proc-error | default | 1 | Error {msg: "surplus"} |
| fork | proc-error | rewrite | 1 | Error {msg: "surplus"} |
| fork | proc-error | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | proc-error | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | proc-error | typed-dump | 0 | typing accepted; typed dump retained |
| fork | proc-fit | default | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | proc-fit | rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | proc-fit | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | proc-fit | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | proc-fit | typed-dump | 0 | typing accepted; typed dump retained |
| fork | proc-long | default | 1 | Error {msg: "ill-formed program: `calling procedure `Symbol(484, SD_Id("f"))' with the wrong number of args: \|args\|=3expecting: 2'"} |
| fork | proc-long | rewrite | 1 | Error {msg: "ill-formed program: `calling procedure `Symbol(484, SD_Id("f"))' with the wrong number of args: \|args\|=3expecting: 2'"} |
| fork | proc-long | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | proc-long | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | proc-long | typed-dump | 0 | typing accepted; typed dump retained |
| fork | proc-short | default | 1 | Error {msg: "ill-formed program: `calling procedure `Symbol(484, SD_Id("f"))' with the wrong number of args: \|args\|=1expecting: 2'"} |
| fork | proc-short | rewrite | 1 | Error {msg: "ill-formed program: `calling procedure `Symbol(484, SD_Id("f"))' with the wrong number of args: \|args\|=1expecting: 2'"} |
| fork | proc-short | typed | 1 | Error {msg: "ill-formed program: `calling procedure `Symbol(484, SD_Id("f"))' with the wrong number of args: \|args\|=1expecting: 2'"} |
| fork | proc-short | typed-rewrite | 1 | Error {msg: "ill-formed program: `calling procedure `Symbol(484, SD_Id("f"))' with the wrong number of args: \|args\|=1expecting: 2'"} |
| fork | proc-short | typed-dump | 0 | typing accepted; typed dump retained |
| fork | pure-let-error | default | 1 | Error {msg: "surplus"} |
| fork | pure-let-error | rewrite | 1 | Error {msg: "surplus"} |
| fork | pure-let-error | typed | 1 | .tmp/item7-audit/core/pure-let-error.core:2:50: error: this expression is of type 'tuple of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | pure-let-error | typed-rewrite | 1 | .tmp/item7-audit/core/pure-let-error.core:2:50: error: this expression is of type 'tuple of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | pure-let-error | typed-dump | 1 | .tmp/item7-audit/core/pure-let-error.core:2:50: error: this expression is of type 'tuple of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | pure-let | default | 1 | Error {msg: "ill-formed program: `PElet: the pattern didn't match pe1'"} |
| fork | pure-let | rewrite | 1 | Error {msg: "ill-formed program: `PElet: the pattern didn't match pe1'"} |
| fork | pure-let | typed | 1 | .tmp/item7-audit/core/pure-let.core:2:50: error: this expression is of type 'tuple of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | pure-let | typed-rewrite | 1 | .tmp/item7-audit/core/pure-let.core:2:50: error: this expression is of type 'tuple of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | pure-let | typed-dump | 1 | .tmp/item7-audit/core/pure-let.core:2:50: error: this expression is of type 'tuple of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | strong-error | default | 1 | Error {msg: "surplus"} |
| fork | strong-error | rewrite | 1 | Error {msg: "surplus"} |
| fork | strong-error | typed | 1 | .tmp/item7-audit/core/strong-error.core:2:40: error: this expression is of type 'unseq of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | strong-error | typed-rewrite | 1 | .tmp/item7-audit/core/strong-error.core:2:40: error: this expression is of type 'unseq of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | strong-error | typed-dump | 1 | .tmp/item7-audit/core/strong-error.core:2:40: error: this expression is of type 'unseq of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | strong-fit | default | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | strong-fit | rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | strong-fit | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | strong-fit | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | strong-fit | typed-dump | 0 | typing accepted; typed dump retained |
| fork | strong-long | default | 1 | Error {msg: "ill-formed program: `Esseq: the pattern didn't match e1'"} |
| fork | strong-long | rewrite | 1 | Error {msg: "ill-formed program: `Esseq: the pattern didn't match e1'"} |
| fork | strong-long | typed | 1 | .tmp/item7-audit/core/strong-long.core:2:40: error: this expression is of type 'unseq of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | strong-long | typed-rewrite | 1 | .tmp/item7-audit/core/strong-long.core:2:40: error: this expression is of type 'unseq of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | strong-long | typed-dump | 1 | .tmp/item7-audit/core/strong-long.core:2:40: error: this expression is of type 'unseq of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | strong-short | default | 1 | Error {msg: "ill-formed program: `Esseq: the pattern didn't match e1'"} |
| fork | strong-short | rewrite | 1 | Error {msg: "ill-formed program: `Esseq: the pattern didn't match e1'"} |
| fork | strong-short | typed | 1 | .tmp/item7-audit/core/strong-short.core:2:51: error: this expression is of type 'unseq of a different arity' but an expression of type '(integer,integer,integer)' was expected |
| fork | strong-short | typed-rewrite | 1 | .tmp/item7-audit/core/strong-short.core:2:51: error: this expression is of type 'unseq of a different arity' but an expression of type '(integer,integer,integer)' was expected |
| fork | strong-short | typed-dump | 1 | .tmp/item7-audit/core/strong-short.core:2:51: error: this expression is of type 'unseq of a different arity' but an expression of type '(integer,integer,integer)' was expected |
| fork | weak-error | default | 1 | Error {msg: "surplus"} |
| fork | weak-error | rewrite | 1 | Error {msg: "surplus"} |
| fork | weak-error | typed | 1 | .tmp/item7-audit/core/weak-error.core:2:38: error: this expression is of type 'unseq of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | weak-error | typed-rewrite | 1 | .tmp/item7-audit/core/weak-error.core:2:38: error: this expression is of type 'unseq of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | weak-error | typed-dump | 1 | .tmp/item7-audit/core/weak-error.core:2:38: error: this expression is of type 'unseq of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | weak-fit | default | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | weak-fit | rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | weak-fit | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | weak-fit | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| fork | weak-fit | typed-dump | 0 | typing accepted; typed dump retained |
| fork | weak-long | default | 1 | Error {msg: "ill-formed program: `Ewseq: the pattern didn't match e1'"} |
| fork | weak-long | rewrite | 1 | Error {msg: "ill-formed program: `Ewseq: the pattern didn't match e1'"} |
| fork | weak-long | typed | 1 | .tmp/item7-audit/core/weak-long.core:2:38: error: this expression is of type 'unseq of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | weak-long | typed-rewrite | 1 | .tmp/item7-audit/core/weak-long.core:2:38: error: this expression is of type 'unseq of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | weak-long | typed-dump | 1 | .tmp/item7-audit/core/weak-long.core:2:38: error: this expression is of type 'unseq of a different arity' but an expression of type '(integer,integer)' was expected |
| fork | weak-short | default | 1 | Error {msg: "ill-formed program: `Ewseq: the pattern didn't match e1'"} |
| fork | weak-short | rewrite | 1 | Error {msg: "ill-formed program: `Ewseq: the pattern didn't match e1'"} |
| fork | weak-short | typed | 1 | .tmp/item7-audit/core/weak-short.core:2:49: error: this expression is of type 'unseq of a different arity' but an expression of type '(integer,integer,integer)' was expected |
| fork | weak-short | typed-rewrite | 1 | .tmp/item7-audit/core/weak-short.core:2:49: error: this expression is of type 'unseq of a different arity' but an expression of type '(integer,integer,integer)' was expected |
| fork | weak-short | typed-dump | 1 | .tmp/item7-audit/core/weak-short.core:2:49: error: this expression is of type 'unseq of a different arity' but an expression of type '(integer,integer,integer)' was expected |
| pristine | case-fallback | default | 1 | .tmp/item7-audit/core/case-fallback.core:2:75: error: unexpected token '=>' |
| pristine | case-fallback | rewrite | 1 | .tmp/item7-audit/core/case-fallback.core:2:75: error: unexpected token '=>' |
| pristine | case-fallback | typed | 1 | .tmp/item7-audit/core/case-fallback.core:2:75: error: unexpected token '=>' |
| pristine | case-fallback | typed-rewrite | 1 | .tmp/item7-audit/core/case-fallback.core:2:75: error: unexpected token '=>' |
| pristine | case-fallback | typed-dump | 1 | .tmp/item7-audit/core/case-fallback.core:2:75: error: unexpected token '=>' |
| pristine | fun-error | default | 1 | Error {msg: "surplus"} |
| pristine | fun-error | rewrite | 1 | Error {msg: "surplus"} |
| pristine | fun-error | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | fun-error | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | fun-error | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | fun-fit | default | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | fun-fit | rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | fun-fit | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | fun-fit | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | fun-fit | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | fun-long | default | 125 | internal error: CALL() \|params\|= 2 <> \|args\|= 3 |
| pristine | fun-long | rewrite | 125 | internal error: CALL() \|params\|= 2 <> \|args\|= 3 |
| pristine | fun-long | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | fun-long | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | fun-long | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | fun-short | default | 125 | internal error: CALL() \|params\|= 2 <> \|args\|= 1 |
| pristine | fun-short | rewrite | 125 | internal error: CALL() \|params\|= 2 <> \|args\|= 1 |
| pristine | fun-short | typed | 125 | internal error: CALL() \|params\|= 2 <> \|args\|= 1 |
| pristine | fun-short | typed-rewrite | 125 | internal error: CALL() \|params\|= 2 <> \|args\|= 1 |
| pristine | fun-short | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | let-error | default | 1 | Error {msg: "surplus"} |
| pristine | let-error | rewrite | 1 | Error {msg: "surplus"} |
| pristine | let-error | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | let-error | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | let-error | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | let-fit | default | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | let-fit | rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | let-fit | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | let-fit | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | let-fit | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | let-long | default | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | let-long | rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | let-long | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | let-long | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | let-long | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | let-nested | default | 0 | Defined {value: "Specified(7)", stdout: "", stderr: "", blocked: "false"} |
| pristine | let-nested | rewrite | 0 | Defined {value: "Specified(7)", stdout: "", stderr: "", blocked: "false"} |
| pristine | let-nested | typed | 0 | Defined {value: "Specified(7)", stdout: "", stderr: "", blocked: "false"} |
| pristine | let-nested | typed-rewrite | 0 | Defined {value: "Specified(7)", stdout: "", stderr: "", blocked: "false"} |
| pristine | let-nested | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | let-short | default | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | let-short | rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | let-short | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | let-short | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | let-short | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | par-fit | default | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | par-fit | rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | par-fit | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | par-fit | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | par-fit | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | par-long | default | 0 | Defined {value: "Specified(5)", stdout: "", stderr: "", blocked: "false"} |
| pristine | par-long | rewrite | 0 | Defined {value: "Specified(5)", stdout: "", stderr: "", blocked: "false"} |
| pristine | par-long | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | par-long | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | par-long | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | proc-error | default | 1 | Error {msg: "surplus"} |
| pristine | proc-error | rewrite | 1 | Error {msg: "surplus"} |
| pristine | proc-error | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | proc-error | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | proc-error | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | proc-fit | default | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | proc-fit | rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | proc-fit | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | proc-fit | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | proc-fit | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | proc-long | default | 1 | Error {msg: "ill-formed program: `calling procedure `Symbol(484, SD_Id("f"))' with the wrong number of args: \|args\|=3expecting: 2'"} |
| pristine | proc-long | rewrite | 1 | Error {msg: "ill-formed program: `calling procedure `Symbol(484, SD_Id("f"))' with the wrong number of args: \|args\|=3expecting: 2'"} |
| pristine | proc-long | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | proc-long | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | proc-long | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | proc-short | default | 1 | Error {msg: "ill-formed program: `calling procedure `Symbol(484, SD_Id("f"))' with the wrong number of args: \|args\|=1expecting: 2'"} |
| pristine | proc-short | rewrite | 1 | Error {msg: "ill-formed program: `calling procedure `Symbol(484, SD_Id("f"))' with the wrong number of args: \|args\|=1expecting: 2'"} |
| pristine | proc-short | typed | 1 | Error {msg: "ill-formed program: `calling procedure `Symbol(484, SD_Id("f"))' with the wrong number of args: \|args\|=1expecting: 2'"} |
| pristine | proc-short | typed-rewrite | 1 | Error {msg: "ill-formed program: `calling procedure `Symbol(484, SD_Id("f"))' with the wrong number of args: \|args\|=1expecting: 2'"} |
| pristine | proc-short | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | pure-let-error | default | 1 | Error {msg: "surplus"} |
| pristine | pure-let-error | rewrite | 1 | Error {msg: "surplus"} |
| pristine | pure-let-error | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | pure-let-error | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | pure-let-error | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | pure-let | default | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | pure-let | rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | pure-let | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | pure-let | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | pure-let | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | strong-error | default | 1 | Error {msg: "surplus"} |
| pristine | strong-error | rewrite | 1 | Error {msg: "surplus"} |
| pristine | strong-error | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | strong-error | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | strong-error | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | strong-fit | default | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | strong-fit | rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | strong-fit | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | strong-fit | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | strong-fit | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | strong-long | default | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | strong-long | rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | strong-long | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | strong-long | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | strong-long | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | strong-short | default | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | strong-short | rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | strong-short | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | strong-short | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | strong-short | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | weak-error | default | 1 | Error {msg: "surplus"} |
| pristine | weak-error | rewrite | 1 | Error {msg: "surplus"} |
| pristine | weak-error | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | weak-error | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | weak-error | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | weak-fit | default | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | weak-fit | rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | weak-fit | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | weak-fit | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | weak-fit | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | weak-long | default | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | weak-long | rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | weak-long | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | weak-long | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | weak-long | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | weak-short | default | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | weak-short | rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | weak-short | typed | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | weak-short | typed-rewrite | 0 | Defined {value: "Specified(3)", stdout: "", stderr: "", blocked: "false"} |
| pristine | weak-short | typed-dump | 0 | typing accepted; typed dump retained |
| fork | run-fixed-error | default | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| fork | run-fixed-error | rewrite | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| fork | run-fixed-error | typed | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| fork | run-fixed-error | typed-rewrite | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| fork | run-fixed-error | typed-dump | 0 | typing accepted; typed dump retained |
| fork | run-fixed-fit | default | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| fork | run-fixed-fit | rewrite | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| fork | run-fixed-fit | typed | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| fork | run-fixed-fit | typed-rewrite | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| fork | run-fixed-fit | typed-dump | 0 | typing accepted; typed dump retained |
| fork | run-fixed-long | default | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| fork | run-fixed-long | rewrite | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| fork | run-fixed-long | typed | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| fork | run-fixed-long | typed-rewrite | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| fork | run-fixed-long | typed-dump | 0 | typing accepted; typed dump retained |
| fork | run-fixed-short | default | 124 | timeout (bounded probe) |
| fork | run-fixed-short | rewrite | 124 | timeout (bounded probe) |
| fork | run-fixed-short | typed | 124 | timeout (bounded probe) |
| fork | run-fixed-short | typed-rewrite | 124 | timeout (bounded probe) |
| fork | run-fixed-short | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | run-fixed-error | default | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| pristine | run-fixed-error | rewrite | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| pristine | run-fixed-error | typed | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| pristine | run-fixed-error | typed-rewrite | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| pristine | run-fixed-error | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | run-fixed-fit | default | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| pristine | run-fixed-fit | rewrite | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| pristine | run-fixed-fit | typed | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| pristine | run-fixed-fit | typed-rewrite | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| pristine | run-fixed-fit | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | run-fixed-long | default | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| pristine | run-fixed-long | rewrite | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| pristine | run-fixed-long | typed | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| pristine | run-fixed-long | typed-rewrite | 0 | Defined {value: "Specified(2)", stdout: "", stderr: "", blocked: "false"} |
| pristine | run-fixed-long | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | run-fixed-short | default | 124 | timeout (bounded probe) |
| pristine | run-fixed-short | rewrite | 124 | timeout (bounded probe) |
| pristine | run-fixed-short | typed | 124 | timeout (bounded probe) |
| pristine | run-fixed-short | typed-rewrite | 124 | timeout (bounded probe) |
| pristine | run-fixed-short | typed-dump | 0 | typing accepted; typed dump retained |
| fork | ccall-error | default | 1 | Error {msg: "surplus"} |
| fork | ccall-error | rewrite | 1 | Error {msg: "surplus"} |
| fork | ccall-error | typed | 125 | internal error: null function pointer |
| fork | ccall-error | typed-rewrite | 125 | internal error: null function pointer |
| fork | ccall-error | typed-dump | 0 | typing accepted; typed dump retained |
| fork | ccall-fit | default | 125 | internal error: null function pointer |
| fork | ccall-fit | rewrite | 125 | internal error: null function pointer |
| fork | ccall-fit | typed | 125 | internal error: null function pointer |
| fork | ccall-fit | typed-rewrite | 125 | internal error: null function pointer |
| fork | ccall-fit | typed-dump | 0 | typing accepted; typed dump retained |
| fork | ccall-short | default | 125 | internal error: null function pointer |
| fork | ccall-short | rewrite | 125 | internal error: null function pointer |
| fork | ccall-short | typed | 125 | internal error: null function pointer |
| fork | ccall-short | typed-rewrite | 125 | internal error: null function pointer |
| fork | ccall-short | typed-dump | 0 | typing accepted; typed dump retained |
| fork | memop-error | default | 1 | Error {msg: "surplus"} |
| fork | memop-error | rewrite | 1 | Error {msg: "surplus"} |
| fork | memop-error | typed | 0 | Defined {value: "Specified(1)", stdout: "", stderr: "", blocked: "false"} |
| fork | memop-error | typed-rewrite | 0 | Defined {value: "Specified(1)", stdout: "", stderr: "", blocked: "false"} |
| fork | memop-error | typed-dump | 0 | typing accepted; typed dump retained |
| fork | memop-fit | default | 0 | Defined {value: "Specified(1)", stdout: "", stderr: "", blocked: "false"} |
| fork | memop-fit | rewrite | 0 | Defined {value: "Specified(1)", stdout: "", stderr: "", blocked: "false"} |
| fork | memop-fit | typed | 0 | Defined {value: "Specified(1)", stdout: "", stderr: "", blocked: "false"} |
| fork | memop-fit | typed-rewrite | 0 | Defined {value: "Specified(1)", stdout: "", stderr: "", blocked: "false"} |
| fork | memop-fit | typed-dump | 0 | typing accepted; typed dump retained |
| fork | memop-short | default | 125 | internal error: INVALID memop request: ptreq ==> (NULL(void)) |
| fork | memop-short | rewrite | 125 | internal error: INVALID memop request: ptreq ==> (NULL(void)) |
| fork | memop-short | typed | 125 | internal error: INVALID memop request: ptreq ==> (NULL(void)) |
| fork | memop-short | typed-rewrite | 125 | internal error: INVALID memop request: ptreq ==> (NULL(void)) |
| fork | memop-short | typed-dump | 0 | typing accepted; typed dump retained |
| fork | run-short-control | default | 0 | Defined {value: "Specified(21)", stdout: "", stderr: "", blocked: "false"} |
| fork | run-short-control | rewrite | 0 | Defined {value: "Specified(21)", stdout: "", stderr: "", blocked: "false"} |
| fork | run-short-control | typed | 0 | Defined {value: "Specified(21)", stdout: "", stderr: "", blocked: "false"} |
| fork | run-short-control | typed-rewrite | 0 | Defined {value: "Specified(21)", stdout: "", stderr: "", blocked: "false"} |
| fork | run-short-control | typed-dump | 0 | typing accepted; typed dump retained |
| fork | run-short-stale | default | 0 | Defined {value: "Specified(11)", stdout: "", stderr: "", blocked: "false"} |
| fork | run-short-stale | rewrite | 0 | Defined {value: "Specified(11)", stdout: "", stderr: "", blocked: "false"} |
| fork | run-short-stale | typed | 0 | Defined {value: "Specified(11)", stdout: "", stderr: "", blocked: "false"} |
| fork | run-short-stale | typed-rewrite | 0 | Defined {value: "Specified(11)", stdout: "", stderr: "", blocked: "false"} |
| fork | run-short-stale | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | ccall-error | default | 1 | Error {msg: "surplus"} |
| pristine | ccall-error | rewrite | 1 | Error {msg: "surplus"} |
| pristine | ccall-error | typed | 125 | internal error: null function pointer |
| pristine | ccall-error | typed-rewrite | 125 | internal error: null function pointer |
| pristine | ccall-error | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | ccall-fit | default | 125 | internal error: null function pointer |
| pristine | ccall-fit | rewrite | 125 | internal error: null function pointer |
| pristine | ccall-fit | typed | 125 | internal error: null function pointer |
| pristine | ccall-fit | typed-rewrite | 125 | internal error: null function pointer |
| pristine | ccall-fit | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | ccall-short | default | 125 | internal error: null function pointer |
| pristine | ccall-short | rewrite | 125 | internal error: null function pointer |
| pristine | ccall-short | typed | 125 | internal error: null function pointer |
| pristine | ccall-short | typed-rewrite | 125 | internal error: null function pointer |
| pristine | ccall-short | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | memop-error | default | 1 | Error {msg: "surplus"} |
| pristine | memop-error | rewrite | 1 | Error {msg: "surplus"} |
| pristine | memop-error | typed | 0 | Defined {value: "Specified(1)", stdout: "", stderr: "", blocked: "false"} |
| pristine | memop-error | typed-rewrite | 0 | Defined {value: "Specified(1)", stdout: "", stderr: "", blocked: "false"} |
| pristine | memop-error | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | memop-fit | default | 0 | Defined {value: "Specified(1)", stdout: "", stderr: "", blocked: "false"} |
| pristine | memop-fit | rewrite | 0 | Defined {value: "Specified(1)", stdout: "", stderr: "", blocked: "false"} |
| pristine | memop-fit | typed | 0 | Defined {value: "Specified(1)", stdout: "", stderr: "", blocked: "false"} |
| pristine | memop-fit | typed-rewrite | 0 | Defined {value: "Specified(1)", stdout: "", stderr: "", blocked: "false"} |
| pristine | memop-fit | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | memop-short | default | 125 | internal error: INVALID memop request: ptreq ==> (NULL(void)) |
| pristine | memop-short | rewrite | 125 | internal error: INVALID memop request: ptreq ==> (NULL(void)) |
| pristine | memop-short | typed | 125 | internal error: INVALID memop request: ptreq ==> (NULL(void)) |
| pristine | memop-short | typed-rewrite | 125 | internal error: INVALID memop request: ptreq ==> (NULL(void)) |
| pristine | memop-short | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | run-short-control | default | 0 | Defined {value: "Specified(21)", stdout: "", stderr: "", blocked: "false"} |
| pristine | run-short-control | rewrite | 0 | Defined {value: "Specified(21)", stdout: "", stderr: "", blocked: "false"} |
| pristine | run-short-control | typed | 0 | Defined {value: "Specified(21)", stdout: "", stderr: "", blocked: "false"} |
| pristine | run-short-control | typed-rewrite | 0 | Defined {value: "Specified(21)", stdout: "", stderr: "", blocked: "false"} |
| pristine | run-short-control | typed-dump | 0 | typing accepted; typed dump retained |
| pristine | run-short-stale | default | 0 | Defined {value: "Specified(11)", stdout: "", stderr: "", blocked: "false"} |
| pristine | run-short-stale | rewrite | 0 | Defined {value: "Specified(11)", stdout: "", stderr: "", blocked: "false"} |
| pristine | run-short-stale | typed | 0 | Defined {value: "Specified(11)", stdout: "", stderr: "", blocked: "false"} |
| pristine | run-short-stale | typed-rewrite | 0 | Defined {value: "Specified(11)", stdout: "", stderr: "", blocked: "false"} |
| pristine | run-short-stale | typed-dump | 0 | typing accepted; typed dump retained |
