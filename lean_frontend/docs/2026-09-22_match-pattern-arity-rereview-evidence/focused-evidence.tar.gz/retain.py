"""Copy exact item-7 audit receipts to a new committed evidence directory.
Run only after both runners have finished and the reviewed tree is still clean.
"""
from pathlib import Path
import hashlib,json,shutil,tarfile,subprocess
src=Path('.tmp/item7-audit')
out=Path('lean_frontend/docs/2026-09-22_match-pattern-arity-rereview-evidence')
assert subprocess.check_output(['git','status','--porcelain'],text=True)==''
report=json.loads((src/'full/report.json').read_text())
three=json.loads((src/'three-engine/report.json').read_text())
assert report['status']=='passed' and report['source_unchanged'] and len(report['lanes'])==39
assert three['status']=='passed' and three['source_unchanged']
assert report['source_before']==report['source_after']
assert report['source_before']['head']=='b85f5bc83ed79554af3bd3bb4f4a16582917ccb5'
assert report['source_before']['status']==three['source']['status']==''
lines=(src/'three-engine.log').read_text().splitlines(keepends=True)
assert lines[-3].startswith('Independent oracle scope:')
assert lines[-2].startswith('Three-engine report (Lean column, NOT gating):')
assert lines[-1].startswith('Independent oracle: passed;')
(src/'three-engine/summary.txt').write_text(''.join(lines[-3:]))
expected=json.loads((src/'expected-lean-differences.json').read_text())
observed={r['id']:r['lean']['status'] for r in three['rows'] if r['id'] in three['lean_differences']}
comparison={'provenance':'[AGENT] derived historical comparison; see three-engine-reference.json',
            'reference':json.loads((src/'three-engine-reference.json').read_text()),
            'head':three['source'],'expected_differences':expected,'observed_differences':observed,
            'same_ids_and_classes':observed==expected}
(src/'three-engine-comparison.json').write_text(json.dumps(comparison,indent=2)+'\n')
out.mkdir()
for original,name in [('full/report.json','release-report.json'),('full/summary.txt','release-summary.txt'),
 ('reviewed-files.json','reviewed-files.json'),('worker-evidence-review.json','worker-evidence-review.json'),
 ('verify_evidence.py','verify_evidence.py'),('evidence-README.md','README.md'),
 ('expected-lean-differences.json','expected-lean-differences.json'),('three-engine-reference.json','three-engine-reference.json')]:
 shutil.copyfile(src/original,out/name)
with tarfile.open(out/'lane-receipts.tar.gz','w:gz') as tf:
 for lane in report['lanes']:
  for stream in ['stdout','stderr']:
   tf.add(src/'full'/lane['id']/stream,arcname=lane['id']+'/'+stream,recursive=False)
reports=[src/'full'/lane/'independent-oracle/report.json' for lane in ['B10.1','B10.2','B12']]+[src/'three-engine/report.json']
with tarfile.open(out/'pristine-reports.tar.gz','w:gz') as tf:
 for p in reports: tf.add(p,arcname=str(p.relative_to(src)).removeprefix('full/'),recursive=False)
 tf.add(src/'three-engine/summary.txt',arcname='three-engine/summary.txt',recursive=False)
def captures(value):
 if isinstance(value,dict):
  if 'capture' in value: yield value
  for v in value.values(): yield from captures(v)
 elif isinstance(value,list):
  for v in value: yield from captures(v)
with tarfile.open(out/'pristine-captures.tar.gz','w:gz') as tf:
 seen=set()
 for report_path in reports:
  for capture in captures(json.loads(report_path.read_text())):
   prefix=Path(capture['capture'])
   for suffix in ['.stdout','.stderr','.status','.command.json']:
    p=prefix.with_suffix(suffix)
    if suffix=='.command.json' and not p.exists(): continue
    name=str(p.relative_to(src.resolve())).removeprefix('full/')
    if name not in seen:
     seen.add(name);tf.add(p,arcname=name,recursive=False)
with tarfile.open(out/'focused-evidence.tar.gz','w:gz') as tf:
 # Top-level files contain the exact probe commands, logs, result JSON and analyses.
 # Omit only the mutable draft and this README's copied source.
 names=[str(p.relative_to(src)) for p in sorted(src.iterdir()) if p.is_file() and p.name not in ['audit-draft.md','evidence-README.md']]
 for directory in ['core','core-captures','adjacent-core','adjacent-captures']:
  names += [str(p.relative_to(src)) for p in sorted((src/directory).rglob('*')) if p.is_file()]
 names += ['native/'+n for n in ['Item7Audit.lean','lakefile.toml','lake-manifest.json','lean-toolchain']]
 for name in sorted(set(names)): tf.add(src/name,arcname=name,recursive=False)
print(out)
