"""Copy exact audit receipts to a new committed evidence directory."""
from pathlib import Path
import hashlib, json, shutil, tarfile

src=Path('.tmp/run-digest-audit')
out=Path('lean_frontend/docs/2026-09-22_run-digest-audit-evidence')
lines=(src/'three-engine.log').read_text().splitlines(keepends=True)
assert lines[-3].startswith('Independent oracle scope:')
assert lines[-2].startswith('Three-engine report (Lean column, NOT gating):')
assert lines[-1].startswith('Independent oracle: passed;')
(src/'three-engine/summary.txt').write_text(''.join(lines[-3:]))
out.mkdir()
for original, name in [('full/report.json','release-report.json'),('full/summary.txt','release-summary.txt'),
                       ('preflight.json','preflight.json'),('reviewed-files.json','reviewed-files.json'),
                       ('worker-evidence-review.txt','worker-evidence-review.txt'),
                       ('verify_evidence.py','verify_evidence.py'),
                       ('evidence-README.md','README.md')]:
    shutil.copyfile(src/original,out/name)
report=json.loads((src/'full/report.json').read_text())
with tarfile.open(out/'lane-receipts.tar.gz','w:gz') as tf:
    for lane in report['lanes']:
        for stream in ['stdout','stderr']:
            tf.add(src/'full'/lane['id']/stream,arcname=lane['id']+'/'+stream,recursive=False)
with tarfile.open(out/'pristine-reports.tar.gz','w:gz') as tf:
    for lane in ['B10.1','B10.2','B12']:
        p=Path(lane)/'independent-oracle/report.json'
        tf.add(src/'full'/p,arcname=str(p),recursive=False)
    for name in ['report.json','summary.txt']:
        tf.add(src/'three-engine'/name,arcname='three-engine/'+name,recursive=False)
worker=json.loads(Path('lean_frontend/docs/2026-09-22_run-digest-as-state-evidence/three-engine-report.json').read_text())
(out/'expected-lean-differences.json').write_text(json.dumps({
    row['id']: row['lean']['status'] for row in worker['rows']
    if row['id'] in worker['lean_differences']}, indent=2, sort_keys=True)+'\n')

def captures(value):
    if isinstance(value, dict):
        if 'capture' in value:
            yield value
        for child in value.values():
            yield from captures(child)
    elif isinstance(value, list):
        for child in value:
            yield from captures(child)

reports = [src/'full'/lane/'independent-oracle/report.json'
           for lane in ['B10.1','B10.2','B12']] + [src/'three-engine/report.json']
with tarfile.open(out/'pristine-captures.tar.gz','w:gz') as tf:
    seen = set()
    for report_path in reports:
        for capture in captures(json.loads(report_path.read_text())):
            prefix = Path(capture['capture'])
            for suffix in ['.stdout','.stderr','.status','.command.json']:
                p = prefix.with_suffix(suffix)
                if suffix == '.command.json' and not p.exists():
                    continue  # synthetic plant captures have no invocation
                name = str(p.relative_to(src.resolve())).removeprefix('full/')
                if name not in seen:
                    seen.add(name)
                    tf.add(p,arcname=name,recursive=False)
with tarfile.open(out/'focused-evidence.tar.gz','w:gz') as tf:
    names=['rebuild.sh','queued_build.py','rebuild.json','rebuild.log','build-queue.jsonl',
           'native-build.log','native-build-attempt1.log','native-build-attempt2.log','native-run.log',
           'optional.log','check-optional.py','check-evidence.py','implementation.diff',
           'review-surface.json','full.log','three-engine.log','three-engine-comparison.json','retain.py',
           'native/AuditCone.lean','native/DigestAudit.lean','native/lakefile.toml',
           'native/lake-manifest.json','native/lean-toolchain']
    names += [str(p.relative_to(src)) for p in sorted((src/'optional').glob('*.ml'))]
    for name in names:
        tf.add(src/name,arcname=name,recursive=False)
print(out)
