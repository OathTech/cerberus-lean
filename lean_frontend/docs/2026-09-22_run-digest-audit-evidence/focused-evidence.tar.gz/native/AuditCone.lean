import Lean
import Driver
import CerbCall
import Translation
import Cabs_to_ail
import Mini_pipeline

-- Same conservative kernel-closure algorithm as Unit.FuelFormsTool, copied
-- into a namespace because importing that executable would import its main.
namespace DigestCone
open Lean

def siblings (env : Environment) (n : Name) : List Name :=
  match Lean.Elab.Structural.eqnInfoExt.find? env n with
  | some info => info.declNames.toList
  | none =>
    match Lean.Elab.WF.eqnInfoExt.find? env n with
    | some info => info.declNames.toList
    | none => []

partial def closure (env : Environment) (roots : List Name) : NameSet := Id.run do
  let mut seen : NameSet := {}
  let mut stack := roots
  while true do
    match stack with
    | [] => break
    | n :: rest =>
      stack := rest
      if seen.contains n then continue
      seen := seen.insert n
      match env.find? n with
      | some ci =>
        for c in ci.getUsedConstantsAsSet do
          if !seen.contains c then stack := c :: stack
        for s in siblings env n do
          if !seen.contains s then stack := s :: stack
      | none => pure ()
  return seen

run_cmd do
  let env ← getEnv
  let runtimeRoots : List Name := [
    `fresh_given_int, `fresh_symbol', `initial_core_run_state,
    `initial_core_run_state_given, `initial_driver_state,
    `initial_driver_state_given, `drive, `driver2, `CerbCall.driveCall]
  for root in runtimeRoots do
    unless (env.find? root).isSome do throwError "missing runtime entry {root}"
    let cone := closure env [root]
    for forbidden in [`CerberusFresh.digest, `CerberusFresh.digestIO, `CerberusFresh.setDigestIO] do
      if cone.contains forbidden then throwError "{root} reaches ambient digest seam {forbidden}"
    logInfo m!"PASS: {root} kernel dependency closure excludes ambient digest seams"
  for root in [`fresh_elab_sym, `fresh_elab_pretty_with_id, `with_block_objects, `translate, `evalConstantExpressionAux] do
    unless (env.find? root).isSome do throwError "missing frontend control {root}"
    unless (closure env [root]).contains `CerberusFresh.digest do
      throwError "frontend positive control {root} lost the digest seam"
    logInfo m!"PASS: frontend control {root} reaches CerberusFresh.digest"

end DigestCone
