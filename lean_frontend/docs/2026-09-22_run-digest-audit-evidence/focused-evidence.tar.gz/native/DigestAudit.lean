import AuditCone
import Driver
import CerbCall
import CabsImport
import Translation_effect

namespace DigestAudit

def digestOf : sym → String | Symbol d _ _ => d

theorem mint_all (rs : core_run_state) :
    fresh_symbol' rs =
      (Symbol rs.sym_digest rs.sym_supply SD_None,
       { rs with sym_supply := rs.sym_supply + 1 }) := rfl

theorem entry_all (n : Nat) (top : Int) (d : String)
    (f : file core_run_annotation) (fs : CerbFS.FsState) :
    (initial_driver_state n top d f fs).1.core_run_state0.sym_digest = d := rfl

theorem given_all (n : Nat) (top : Int) (d : String)
    (f : file core_run_annotation) (fs : CerbFS.FsState) :
    (initial_driver_state_given n top d f fs).1.core_run_state0.sym_digest = d := rfl

theorem action_preserves (rs : core_run_state) :
    (fresh_action_id' rs).2.sym_digest = rs.sym_digest := rfl

theorem spawn_preserves (parent : Option thread_id) (th : thread_state)
    (cs : core_state) (rs : core_run_state) :
    (spawn_thread parent th cs rs).2.sym_digest = rs.sym_digest := rfl

theorem excluded_update_all (rs : core_run_state) :
    E.fresh_excluded_id (a := Unit) rs =
      Result (Defined rs.excluded_supply,
        { rs with excluded_supply := rs.excluded_supply + 1 }) := rfl

#print axioms excluded_update_all
#print axioms mint_all
#print axioms entry_all
#print axioms given_all
#print axioms action_preserves
#print axioms spawn_preserves

def argPrefix : generic_expr core_run_annotation Unit sym → Option String
  | Expr _ (Ewseq _ (Expr _ (Eaction (Paction _ (Action _ _
      (Create _ _ (PrefFunArg _ d _)))))) _) => some d
  | _ => none

def a : String := "900150983cd24fb0d6963f7d28e17f72"
def b : String := "9e107d9d372bb6826bd81d3542a419d6"
def x : String := "00000000000000000000000000000000"
def y : String := "ffffffffffffffffffffffffffffffff"

def require (label : String) (test : Bool) : IO Unit := do
  unless test do throw (IO.userError s!"FAIL: {label}")
  IO.println s!"PASS: {label}"

-- The same frontend closures are reused across writes. The barrier forces
-- evaluation at each intended point, as in the production frontend.
def frontendChecks (dg : String) (sup : Nat)
    (plain pretty : elab_state → sym × elab_state) : IO Unit := do
  let _ ← (CerberusFresh.setDigestIO dg : BaseIO Unit)
  let (s, next) ← (CerberusFresh.forceIO (fun () => plain (elab_init sup Normal_callconv)) : BaseIO _)
  require "frontend fresh_elab_sym picks current TU" (digestOf s == dg && next.fresh_supply == sup + 1)
  let (p, nextp) ← (CerberusFresh.forceIO (fun () => pretty (elab_init sup Normal_callconv)) : BaseIO _)
  require "frontend pretty mint picks current TU" (digestOf p == dg && nextp.fresh_supply == sup + 1)
  let quals : qualifiers := { const := true, restrict := false, volatile := false }
  let r ← (CerberusFresh.forceIO (fun () =>
    with_block_objects [(Symbol "library" 1 SD_None, (quals, signed_int))]
      (fun st => ((), st)) (elab_init sup Normal_callconv)) : BaseIO _)
  match r.1.1 with
  | [(_, (_, _, alias))] =>
      require "frontend const alias picks current TU" (digestOf alias == dg && r.2.fresh_supply == sup + 1)
  | _ => throw (IO.userError "FAIL: const alias probe did not mint exactly one alias")

def test : IO Unit := do
  let sa := initial_core_run_state_given 41 a fmapEmpty
  let sb := initial_core_run_state_given 73 b fmapEmpty
  let plain := fresh_elab_sym SD_None
  let pretty := fresh_elab_pretty_with_id (fun n => s!"audit_{n}")
  for ambient in [x, y, ""] do
    frontendChecks ambient 99 plain pretty
    let (ma, sa') ← (CerberusFresh.forceIO (fun () => fresh_symbol' sa) : BaseIO _)
    let (mb, sb') ← (CerberusFresh.forceIO (fun () => fresh_symbol' sb) : BaseIO _)
    require "run A ignores ambient digest" (ma == Symbol a 41 SD_None && sa'.sym_digest == a && sa'.sym_supply == 42)
    require "run B ignores ambient digest" (mb == Symbol b 73 SD_None && sb'.sym_digest == b && sb'.sym_supply == 74)
    let ma2 ← (CerberusFresh.forceIO (fun () => (fresh_symbol' sa').1) : BaseIO _)
    require "second mint preserves seeded digest" (ma2 == Symbol a 42 SD_None)
    let call ← (CerberusFresh.forceIO (fun () =>
      CerbCall.argCreate a (Symbol "" 1 SD_None) (Symbol "" 2 SD_None)
        signed_int (CerbCall.intValue 7) 0) : BaseIO _)
    require "call argument prefix uses explicit digest" (argPrefix call == some a)
  for dg in ["", a, b, "arbitrary λ data"] do
    require "mint is a constructor for every supplied digest" (fresh_given_int dg 31 == Symbol dg 31 SD_None)
  require "three TUs select final input" (runDigest [(a,TUnit []),(b,TUnit []),(x,TUnit [])] == x)

end DigestAudit

def main : IO UInt32 := do
  DigestAudit.test
  IO.println "DigestAudit: all native and kernel checks passed"
  return 0
