#!/usr/bin/env bash
set -euo pipefail
export DUNE_CACHE=disabled CERB_MEM_MAX=32G
make prelude-src lean-prelude-src
opam exec --switch=. -- dune build --root . --force backend/driver/main.exe cerberus-lib.install cerberus.install
source scripts/common.sh
build_cerberus
build_lean
python3 scripts/ensure_independent_oracle.py
git status --short
