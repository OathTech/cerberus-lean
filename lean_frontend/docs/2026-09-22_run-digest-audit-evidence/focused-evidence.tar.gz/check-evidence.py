from pathlib import Path
import hashlib, json, subprocess
p=Path('lean_frontend/docs/2026-09-22_run-digest-as-state-evidence')
r=json.loads((p/'report.json').read_text())
print('Worker report: passed=',r['status']=='passed','complete=',r['selection_complete'],'source unchanged=',r['source_unchanged'])
assert r['source_before']==r['source_after']
assert r['external_inputs_before']==r['external_inputs_after']
assert len(r['lanes'])==39 and all(x['status']=='passed' and x['exit_status']==0 for x in r['lanes'])
print('Worker full report: all 39 commands passed; source and external identities equal')
changes=[k for k,v in r['artifacts_before'].items() if v!=r['artifacts_after'].get(k)]
print('Recorded artifact identities changed (this report does not certify artifact immutability):',len(changes))
for k in changes: print(' ',k)
three=json.loads((p/'three-engine-report.json').read_text())
assert three['status']=='passed' and three['source_unchanged']
print('Worker three-engine counts:',three['counts'])
print('Worker three-engine Lean counts:',three['lean_counts'])
for path,section in [('driver_fresh.lean.sha256','lean'),('driver_fresh.oracle.sha256','oracle'),('lean_frontend/lem_sync.sha256','lean-generation'),('ocaml_frontend/lem_sync.sha256','ocaml-generation')]:
 print(section,'worker final stamp:',repr(r['artifacts_after'][path]['text']))
