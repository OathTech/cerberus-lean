open Cerb_frontend
open Cerb_backend
open Cerb_util
let check (dummy_file : Core_run_aux.core_run_annotation Core.file) : Driver.driver_state =
  Driver.initial_driver_state Cerb_backend.Driver_ocaml.address_space_top_default (Cerb_fresh.digest ()) dummy_file
        Sibylfs.fs_initial_state
