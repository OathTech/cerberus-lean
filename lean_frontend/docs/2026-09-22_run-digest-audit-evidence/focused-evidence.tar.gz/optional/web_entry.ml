open Cerb_frontend
open Cerb_backend
open Cerb_util
type conf = { pipeline : Pipeline.configuration }
let check (conf : conf) (core' : Core_run_aux.core_run_annotation Core.file) : Driver.driver_state =
  Driver.initial_driver_state conf.pipeline.address_space_top (Cerb_fresh.digest ()) core' Sibylfs.fs_initial_state
