import datetime, json, os, subprocess, time
from pathlib import Path
root = Path('.tmp/run-digest-audit')

def external_jobs():
    jobs = []
    for row in subprocess.check_output(['ps','-eo','pid=,comm=,args='],text=True).splitlines():
        parts=row.split(None,2)
        if len(parts)!=3: continue
        pid,comm,args=parts
        if int(pid)==os.getpid(): continue
        if comm in ('lean','lem') or (comm in ('lake','dune') and ' build' in args) or (comm.startswith('python') and 'scripts/release.py' in args):
            jobs.append({'pid':int(pid),'comm':comm,'args':args})
    return jobs

while True:
    jobs=external_jobs()
    row={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'jobs':jobs,'load':os.getloadavg()}
    with (root/'build-queue.jsonl').open('a') as f: f.write(json.dumps(row)+'\n')
    if not jobs: break
    time.sleep(30)
start=time.monotonic()
cmd=['bash',str(root/'rebuild.sh')]
with (root/'rebuild.log').open('w') as f:
    p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=1800)
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'exit_code':p.returncode,'wall_seconds':time.monotonic()-start}
(root/'rebuild.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
raise SystemExit(p.returncode)
