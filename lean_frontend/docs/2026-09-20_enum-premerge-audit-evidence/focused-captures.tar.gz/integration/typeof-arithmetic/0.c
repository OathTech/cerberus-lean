enum E {A,B};int main(void){enum E e=B;typeof(e+1)y=3;return y;}
