enum E {A=-1,B}; enum E g=A; int f(enum E x){return (g<0)+2*(x<0);} int main(void){return f(A);}
