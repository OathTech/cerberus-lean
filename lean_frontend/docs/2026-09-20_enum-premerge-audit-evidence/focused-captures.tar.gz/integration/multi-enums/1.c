enum E {A,B}; enum E global_b=(enum E)-1; int f(void); int main(void){return f()+2*(global_b>0);}
