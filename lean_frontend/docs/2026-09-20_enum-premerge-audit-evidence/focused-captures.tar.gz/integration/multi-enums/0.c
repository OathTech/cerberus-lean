enum E {A=-1,B}; enum E global_a=A; int f(void){return global_a<0;}
