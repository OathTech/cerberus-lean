enum E {A=-1,B}; struct S {enum E x;}; extern struct S s; int f(void); int main(void){return (s.x==f())+2*(s.x<0);}
