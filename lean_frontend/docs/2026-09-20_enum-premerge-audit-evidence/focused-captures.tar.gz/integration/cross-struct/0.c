enum E {A=-1,B}; struct S {enum E x;}; struct S s={A}; int f(void){return s.x;}
